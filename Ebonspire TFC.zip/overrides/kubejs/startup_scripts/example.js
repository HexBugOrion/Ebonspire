// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded startup scripts)')


StartupEvents.registry('item', event => {
    event.create("paper_pulp")
    event.create("raw_paper")
})

