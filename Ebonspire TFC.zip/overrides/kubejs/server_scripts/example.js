// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded server scripts)')

ServerEvents.tags("tag", event => {

    //event.add("softwood_logs","tfc:wood/log/douglas_fir","tfc:wood/log/willow")

})

ServerEvents.recipes(event => {

    event.shapeless(
        Item.of("8x kubejs:raw_paper"),
        [
            "1x kubejs:paper_pulp",
            "1x #tfc:sewing_dark_cloth"
        ]
    )

    event.shaped(
        Item.of("1x minecraft:tnt"),
        [
            "gsg",
            "sgs",
            "gsg"
        ],
        {
            "g":"minecraft:gunpowder",
            "s":"#minecraft:sand"
        }
    )

    //IA items

    event.remove("immersive_aircraft:propeller")

    event.shaped(
        Item.of("immersive_aircraft:propeller"),
        [
            "ps ",
            " r ",
            " sp"
        ],
        {
            "p":"tfc:metal/sheet/steel",
            "s":"tfc_items:steel_screw",
            "r":"tfc:metal/rod/steel"
        }
    )

    event.remove("immersive_aircraft:enhanced_propeller")

    event.shaped(
        Item.of("immersive_aircraft:enhanced_propeller"),
        [
            "ps ",
            "srs",
            " sp"
        ],
        {
            "p":"tfc:metal/double_sheet/black_steel",
            "s":"tfc_items:black_steel_rivet",
            "r":"immersive_aircraft:propeller"
        }
    )

    event.remove("immersive_aircraft:hull")

    event.shaped(
        Item.of("immersive_aircraft:hull"),
        [
            "sps",
            "www",
            "sps"
        ],
        {
            "s":"tfc_items:steel_screw",
            "p":"tfc_ie_addon:metal/sheet/aluminum",
            "w":"#tfc:lumber"
        }
    )

    event.remove("immersive_aircraft:hull_reinforcement")

    event.shaped(
        Item.of("immersive_aircraft:hull_reinforcement"),
        [
            "psp",
            "hhh",
            "psp"
        ],
        {
            "p":"tfc:metal/double_sheet/black_steel",
            "s":"tfc_items:black_steel_rivet",
            "h":"immersive_aircraft:hull"
        }
    )

    event.remove("immersive_aircraft:sail")

    event.shaped(
        Item.of("immersive_aircraft:sail"),
        [
            "ccs",
            "ccs",
            "ccs"
        ],
        {
            "c":"#tfc:sewing_dark_cloth",
            "s":"#forge:string"
        }
    )

    event.remove("immersive_aircraft:boiler")

    event.shaped(
        Item.of("immersive_aircraft:boiler"),
        [
            " s ",
            "s s",
            "isi"
        ],
        {
            "s":"tfc:metal/double_sheet/brass",
            "i":"tfc:metal/sheet/wrought_iron"
        }
    )

    event.remove("immersive_aircraft:steel_boiler")

    event.shaped(
        Item.of("immersive_aircraft:steel_boiler"),
        [
            "sBs",
            "BbB",
            "sBs"
        ],
        {
            "s":"tfc:metal/sheet/steel",
            "B":"tfc:metal/double_sheet/black_steel",
            "b":"immersive_aircraft:boiler"
        }
    )

    event.remove("immersive_aircraft:engine")

    event.shaped(
        Item.of("immersive_aircraft:engine"),
        [
            " s ",
            "pbp",
            "sss"
        ],
        {
            "s":"tfc:metal/sheet/steel",
            "p":"minecraft:piston",
            "b":"immersive_aircraft:boiler"
        }
    )

    event.remove("immersive_aircraft:sturdy_pipes")

    event.shaped(
        Item.of("immersive_aircraft:sturdy_pipes"),
        [
            "ptp"
        ],
        {
            "p":"tfc:metal/sheet/brass",
            "t":"tfc:metal/tuyere/steel"
        }
    )

    event.remove("immersive_aircraft:industrial_gears")

    event.shaped(
        Item.of("immersive_aircraft:industrial_gears"),
        [
            " g ",
            "srg",
            " s "
        ],
        {
            "g":"tfc_items:brass_gear",
            "s":"tfc_items:steel_gear",
            "r":"tfc:metal/rod/wrought_iron"
        }
    )

    event.remove("immersive_aircraft:improved_landing_gear")

    event.shaped(
        Item.of("immersive_aircraft:improved_landing_gear"),
        [
            " r",
            "w "
        ],
        {
            "r":"tfc:metal/rod/steel",
            "w":"#tfcastikorcarts:cart_wheel"
        }
    )

    event.remove("immersive_aircraft:rotary_cannon")

    event.shaped(
        Item.of("immersive_aircraft:rotary_cannon"),
        [
            " t ",
            "cmc",
            "sis"
        ],
        {
            "t":"tfc:metal/tuyere/black_steel",
            "s":"tfc:metal/sheet/steel",
            "c":"tfc:metal/sheet/copper",
            "m":"tfc:brass_mechanisms",
            "i":"tfc:metal/rod/wrought_iron"
        }
    )

    event.remove("immersive_aircraft:telescope")

    event.shaped(
        Item.of("immersive_aircraft:telescope"),
        [
            "t",
            "m"
        ],
        {
            "t":"minecraft:spyglass",
            "m":"tfc:brass_mechanisms"
        }
    )

    event.remove("immersive_aircraft:bomb_bay")

    event.shaped(
        Item.of("immersive_aircraft:bomb_bay"),
        [
            "s s",
            "ptp"
        ],
        {
            "s":"tfc:metal/sheet/black_steel",
            "p":"minecraft:piston",
            "t":"tfc:metal/trapdoor/black_steel"
        }
    )

    event.remove("immersive_aircraft:gyroscope")

    event.shaped(
        Item.of("immersive_aircraft:gyroscope"),
        [
            " l ",
            "mom",
            " s "
        ],
        {
            "l":"tfc:lens",
            "m":"tfc:brass_mechanisms",
            "o":"minecraft:compass",
            "s":"tfc:metal/sheet/wrought_iron"
        }
    )

    event.remove("immersive_aircraft:nether_engine")

    event.shaped(
        Item.of("immersive_aircraft:nether_engine"),
        [
            "sds",
            "ded",
            "sds"
        ],
        {
            "s":"tfc:metal/sheet/blue_steel",
            "d":"tfc:metal/double_sheet/blue_steel",
            "e":"immersive_aircraft:engine"
        }
    )

    event.remove("immersive_aircraft:eco_engine")

    event.shaped(
        Item.of("immersive_aircraft:eco_engine"),
        [
            "sds",
            "ded",
            "sds"
        ],
        {
            "s":"tfc:metal/sheet/red_steel",
            "d":"tfc:metal/double_sheet/red_steel",
            "e":"immersive_aircraft:engine"
        }
    )

    event.remove("immersive_aircraft:cargo_airship")

    event.shaped(
        Item.of("immersive_aircraft:cargo_airship"),
        [
            "cac",
            "chc"
        ],
        {
            "c":"#forge:chests",
            "a":"immersive_aircraft:airship",
            "h":"immersive_aircraft:hull"
        }
    )

    event.remove("immersive_aircraft:gyroscope_dials")

    event.shaped(
        Item.of("immersive_aircraft:gyroscope_dials"),
        [
            "mmm",
            "ngl"
        ],
        {
            "m":"tfc:brass_mechanisms",
            "n":"minecraft:note_block",
            "g":"immersive_aircraft:gyroscope",
            "l":"minecraft:lever"
        }
    )

    event.remove("immersive_aircraft:gyroscope_hud")

    event.remove({ id: 'immersiveengineering:crafting/railgun' })

    event.shaped(
        Item.of("immersiveengineering:railgun"),
        [
            " ag",
            "rce",
            "cb "

        ],
        {
            "a":"immersiveengineering:capacitor_hv",
            "g":"immersiveengineering:wooden_grip",
            "r":"tfc:metal/double_sheet/red_steel",
            "c":"immersiveengineering:coil_mv",
            "e":"immersiveengineering:component_electronic_adv",
            "b":"tfc:metal/double_sheet/blue_steel"
        }
    )

    event.custom({
        type: "firmalife:drying",
        ingredient: {
            item: "kubejs:raw_paper"
        },
        result: "minecraft:paper"
    })

    event.custom({
        type: "tfc:barrel_sealed",
        input_item: {
            ingredient: {
                item: "farmersdelight:tree_bark"
            }
        },
        input_fluid: {
            ingredient: "tfc:lye",
            amount: 125
        },
        output_item: {
            item: "kubejs:paper_pulp",
            count: 6
        },
        duration: 8000
    })
})
