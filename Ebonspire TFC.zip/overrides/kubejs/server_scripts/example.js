// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded server scripts)')

ServerEvents.recipes(event => {

    event.shapeless(
        Item.of("8x kubejs:raw_paper"),
        [
            "1x kubejs:paper_pulp",
            "1x #tfc:sewing_dark_cloth"
        ]
    )


    event.custom({
        type: "firmalife:drying",
        ingredient: {
            item: "kubejs:raw_paper"
        },
        result: "minecraft:paper"
    })

    event.custom({
        type: "tfc:barrel_sealed",
        input_item: {
            ingredient: {
                item: "farmersdelight:tree_bark"
            }
        },
        input_fluid: {
            ingredient: "tfc:lye",
            amount: 125
        },
        output_item: {
            item: "kubejs:paper_pulp",
            count: 6
        },
        duration: 8000
    })
})
